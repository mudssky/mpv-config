# Installation
> `npm install --save @types/mpv-script`

# Summary
This package contains type definitions for mpv-script (https://github.com/mpv-player/mpv).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mpv-script.

### Additional Details
 * Last updated: Wed, 29 Jul 2020 21:00:21 GMT
 * Dependencies: none
 * Global values: `dump`, `exit`, `mp`, `print`

# Credits
These definitions were written by [David T](https://github.com/mrxdst).
